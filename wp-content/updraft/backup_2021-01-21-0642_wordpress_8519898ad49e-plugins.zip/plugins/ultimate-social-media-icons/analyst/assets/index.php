<?php
	// Silence is golden.
